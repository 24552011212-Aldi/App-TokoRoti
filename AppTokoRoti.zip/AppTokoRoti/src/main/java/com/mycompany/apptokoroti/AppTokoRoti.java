package com.mycompany.apptokoroti;
public class AppTokoRoti {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new UI_RoleSelect().setVisible(true));
    }
}
