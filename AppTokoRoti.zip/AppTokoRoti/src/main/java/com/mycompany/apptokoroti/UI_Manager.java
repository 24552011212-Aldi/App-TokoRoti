package com.mycompany.apptokoroti;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class UI_Manager extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(UI_Manager.class.getName());
    private java.util.List<Produk> listProduk = new java.util.ArrayList<>();
    private TransaksiService transaksiService = new TransaksiService();
    
    private void loadStockProduk() {
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tableStock.getModel();
        model.setRowCount(0); // kosongkan tabel

        // ubah judul kolom sesuai data
        model.setColumnIdentifiers(new Object[] {"Kode", "Nama", "Kategori", "Stok", "Deskripsi", "Harga"});

        for (Produk p : listProduk) {
            model.addRow(new Object[] {
                p.getKode(),
                p.getNama(),
                p.getKategori().getDeskripsi(),
                p.getStokProduk(),
                p.getDeskripsi(),
                p.getHarga()
            });
        }
    }
    
    private void loadKategoriToComboBox() {
        comboKategori.removeAllItems();
        for (KategoriRoti k : KategoriRoti.values()) {
            comboKategori.addItem(k.getDeskripsi()); // masukkan String, bukan enum
        }
    }



    private void setupTableStockEditable() {
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tableStock.getModel();
        tableStock.setModel(model);

        // hanya kolom Stok (index 3) yang bisa diedit
        tableStock.getModel().addTableModelListener(e -> {
            int row = e.getFirstRow();
            int column = e.getColumn();
            if (column == 3) {
                try {
                    int newStok = Integer.parseInt(model.getValueAt(row, column).toString());
                    listProduk.get(row).setStokProduk(newStok);
                    javax.swing.JOptionPane.showMessageDialog(this, "Stok berhasil diperbarui!");
                } catch (NumberFormatException ex) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Masukkan angka valid untuk stok!");
                    // kembalikan nilai lama
                    model.setValueAt(listProduk.get(row).getStokProduk(), row, column);
                }
            }
        });
    }
    
    private void refreshTableStock() {
            DefaultTableModel model = (DefaultTableModel) tableStock.getModel();
            // Kosongkan tabel dulu
            model.setRowCount(0);

            // Tambahkan semua produk
            for (Produk p : ProdukService.getListProduk()) {
            model.addRow(new Object[]{
                p.getKode(),
                p.getNama(),
                p.getKategori().getDeskripsi(), // ambil string dari enum
                p.getStokProduk()
            });
            }
        }
    
    private void refreshTableTransaksi() {
        DefaultTableModel model = (DefaultTableModel) tableTransaksi.getModel();
        model.setRowCount(0); // kosongkan tabel lama

        for (String catatan : AppData.transaksiService.getRiwayatTransaksi()) {
            // Pisahkan atau tampilkan seluruh catatan di satu kolom
            model.addRow(new Object[]{ catatan });
        }
    }

    private void loadRiwayatTransaksi() {
        DefaultTableModel model = (DefaultTableModel) tableTransaksi.getModel();
        model.setRowCount(0);

        transaksiService.loadDataFromFile();

        for (String catatan : transaksiService.tampilSemua()) {
            model.addRow(new Object[]{ catatan });
        }
    }


    private void refreshTableBahan() {
        DefaultTableModel model = (DefaultTableModel) tabelBahanBaku.getModel();
        model.setRowCount(0); // kosongkan tabel lama

        for (BahanBaku b : BahanBakuService.getListBahan()) {
            model.addRow(new Object[]{
                b.getId(),        // ID Bahan
                b.getNama(),      // Nama Bahan
                b.getQuantity()   // Quantity (kg)
            });
        }
    }


    public UI_Manager() {
    initComponents();
    pack(); // Membuat JFrame menyesuaikan ukuran panel
    setLocationRelativeTo(null); // Agar muncul di tengah layar
    refreshTableStock();
    refreshTableTransaksi();
    loadStockProduk();
    setupTableStockEditable();
    loadKategoriToComboBox();
    refreshTableBahan();
    loadRiwayatTransaksi();
    AppData.transaksiService.loadDataFromFile();
    this.transaksiService = AppData.transaksiService;
    this.transaksiService.loadDataFromFile();
    
    
    if (ProdukService.getListProduk().isEmpty()) {
        ProdukService.tambahProduk(new Produk("PRD001", "Roti Tawar", 5000.0, KategoriRoti.TAWAR, 20, "Roti Tawar Lembut"));
        ProdukService.tambahProduk(new Produk("PRD002", "Roti Manis", 7000.0, KategoriRoti.MANIS, 15, "Roti Manis Premium"));
        ProdukService.tambahProduk(new Produk("PRD003", "Roti Asin", 6000.0, KategoriRoti.ASIN, 10, "Roti Asin Gurih"));
    }
    
    tableTransaksi.setModel(new DefaultTableModel(
        new Object [][] {},
        new String [] {"Riwayat Transaksi"}
    ));

    
    String[] kolom = {"ID Bahan", "Nama Bahan", "Quantity (kg)"};
    DefaultTableModel model = new DefaultTableModel(kolom, 0);
    tabelBahanBaku.setModel(model);


    
    tableStock.setModel(new DefaultTableModel(
        new Object [][] {},
        new String [] {"Kode", "Nama", "Kategori", "Stok"}
    ));
 
    tabUtama.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
    

        
        @Override
        protected int calculateTabAreaHeight(
            int tabPlacement,
            int horizRunCount,
            int maxTabHeight
        ) {
            return 0;
        }

        @Override
        protected void paintTabArea(
            java.awt.Graphics g,
            int tabPlacement,
            int selectedIndex
        ) {
        }
    });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        mainPanel = new javax.swing.JPanel();
        tabUtama = new javax.swing.JTabbedPane();
        mainMenu = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelTambah = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tambahBahanBaku = new javax.swing.JButton();
        txtTelur = new javax.swing.JTextField();
        txtTerigu = new javax.swing.JTextField();
        txtGaram = new javax.swing.JTextField();
        txtGula = new javax.swing.JTextField();
        txtSusu = new javax.swing.JTextField();
        panelLihat = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cariBahanBaku = new javax.swing.JButton();
        txtBahanBaku = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelBahanBaku = new javax.swing.JTable();
        tambahProduk = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        txtKode = new javax.swing.JTextField();
        txtNama = new javax.swing.JTextField();
        txtHarga = new javax.swing.JTextField();
        txtStok = new javax.swing.JTextField();
        txtDeskripsi = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        bTambahProduk = new javax.swing.JButton();
        comboKategori = new javax.swing.JComboBox<>();
        kelolaStock = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        txtCariStock = new javax.swing.JTextField();
        bCariStock = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableStock = new javax.swing.JTable();
        SimpanEditStock = new javax.swing.JButton();
        panelRiwayat = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        txtTransaksi = new javax.swing.JTextField();
        bCariTransaksi = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tableTransaksi = new javax.swing.JTable();
        navMainMenu = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        navTambahBahan = new javax.swing.JButton();
        navLihatBahan = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        navTambahProduk = new javax.swing.JButton();
        navKelolaStock = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        navRiwayat = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bg.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(102, 51, 0));

        mainPanel.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Rexx\\Documents\\NetBeansProjects\\Laila\\AppTokoRoti\\src\\main\\resources\\assets\\Untitled-3.png")); // NOI18N

        javax.swing.GroupLayout mainMenuLayout = new javax.swing.GroupLayout(mainMenu);
        mainMenu.setLayout(mainMenuLayout);
        mainMenuLayout.setHorizontalGroup(
            mainMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainMenuLayout.createSequentialGroup()
                .addContainerGap(294, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(256, 256, 256))
        );
        mainMenuLayout.setVerticalGroup(
            mainMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuLayout.createSequentialGroup()
                .addGap(129, 129, 129)
                .addComponent(jLabel2)
                .addContainerGap(202, Short.MAX_VALUE))
        );

        tabUtama.addTab("tab1", mainMenu);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Tambah Bahan Baku");

        jLabel4.setText("Telur (kg) :");

        jLabel9.setText("Terigu (kg) :");

        jLabel10.setText("Garam (kg) :");

        jLabel11.setText("Gula (kg) :");

        jLabel12.setText("Susu (kg) :");

        tambahBahanBaku.setText("Tambah");
        tambahBahanBaku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahBahanBakuActionPerformed(evt);
            }
        });

        txtTelur.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtTelurInputMethodTextChanged(evt);
            }
        });

        txtTerigu.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtTeriguInputMethodTextChanged(evt);
            }
        });

        txtGaram.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtGaramInputMethodTextChanged(evt);
            }
        });

        txtGula.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtGulaInputMethodTextChanged(evt);
            }
        });

        txtSusu.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtSusuInputMethodTextChanged(evt);
            }
        });

        javax.swing.GroupLayout panelTambahLayout = new javax.swing.GroupLayout(panelTambah);
        panelTambah.setLayout(panelTambahLayout);
        panelTambahLayout.setHorizontalGroup(
            panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTambahLayout.createSequentialGroup()
                .addContainerGap(322, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(320, 320, 320))
            .addGroup(panelTambahLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tambahBahanBaku)
                    .addGroup(panelTambahLayout.createSequentialGroup()
                        .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTelur)
                            .addComponent(txtTerigu)
                            .addComponent(txtGaram)
                            .addComponent(txtGula)
                            .addComponent(txtSusu, javax.swing.GroupLayout.DEFAULT_SIZE, 471, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelTambahLayout.setVerticalGroup(
            panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTambahLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelTambahLayout.createSequentialGroup()
                        .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(panelTambahLayout.createSequentialGroup()
                                .addComponent(txtTelur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtTerigu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10))
                    .addComponent(txtGaram, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtGula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelTambahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtSusu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tambahBahanBaku)
                .addContainerGap(226, Short.MAX_VALUE))
        );

        tabUtama.addTab("tab2", panelTambah);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Lihat Bahan Baku");

        cariBahanBaku.setText("Cari");
        cariBahanBaku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariBahanBakuActionPerformed(evt);
            }
        });

        txtBahanBaku.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtBahanBakuInputMethodTextChanged(evt);
            }
        });

        tabelBahanBaku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tabelBahanBaku);

        javax.swing.GroupLayout panelLihatLayout = new javax.swing.GroupLayout(panelLihat);
        panelLihat.setLayout(panelLihatLayout);
        panelLihatLayout.setHorizontalGroup(
            panelLihatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLihatLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(panelLihatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 653, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtBahanBaku, javax.swing.GroupLayout.PREFERRED_SIZE, 655, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelLihatLayout.createSequentialGroup()
                        .addGap(282, 282, 282)
                        .addGroup(panelLihatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelLihatLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(276, 276, 276))
                            .addComponent(cariBahanBaku))))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        panelLihatLayout.setVerticalGroup(
            panelLihatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLihatLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBahanBaku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cariBahanBaku)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        tabUtama.addTab("tab5", panelLihat);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setText("Tambah Produk");

        jLabel17.setText("Kode Produk (PRD000) :");

        jLabel18.setText("Nama Produk :");

        jLabel19.setText("Harga Produk (Rp) :");

        jLabel20.setText("Kategori Produk :");

        jLabel21.setText("Jumlah Produk :");

        jLabel22.setText("Deskripsi Produk :");

        bTambahProduk.setText("Tambah");
        bTambahProduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTambahProdukActionPerformed(evt);
            }
        });

        comboKategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout tambahProdukLayout = new javax.swing.GroupLayout(tambahProduk);
        tambahProduk.setLayout(tambahProdukLayout);
        tambahProdukLayout.setHorizontalGroup(
            tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tambahProdukLayout.createSequentialGroup()
                .addContainerGap(351, Short.MAX_VALUE)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(306, 306, 306))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tambahProdukLayout.createSequentialGroup()
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(tambahProdukLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bTambahProduk))
                    .addGroup(tambahProdukLayout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtKode)
                            .addComponent(txtNama)
                            .addComponent(txtHarga)
                            .addComponent(txtStok)
                            .addComponent(txtDeskripsi)
                            .addComponent(comboKategori, javax.swing.GroupLayout.Alignment.LEADING, 0, 465, Short.MAX_VALUE))))
                .addGap(56, 56, 56))
        );
        tambahProdukLayout.setVerticalGroup(
            tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tambahProdukLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtKode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(comboKategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDeskripsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bTambahProduk)
                .addContainerGap(177, Short.MAX_VALUE))
        );

        tabUtama.addTab("tab5", tambahProduk);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Kelola Stock");

        txtCariStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCariStockActionPerformed(evt);
            }
        });

        bCariStock.setText("Cari");
        bCariStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCariStockActionPerformed(evt);
            }
        });

        tableStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableStock);

        SimpanEditStock.setText("Simpan");
        SimpanEditStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SimpanEditStockActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kelolaStockLayout = new javax.swing.GroupLayout(kelolaStock);
        kelolaStock.setLayout(kelolaStockLayout);
        kelolaStockLayout.setHorizontalGroup(
            kelolaStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kelolaStockLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(317, 317, 317))
            .addGroup(kelolaStockLayout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(kelolaStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SimpanEditStock)
                    .addGroup(kelolaStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(bCariStock)
                        .addComponent(txtCariStock)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 683, Short.MAX_VALUE)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        kelolaStockLayout.setVerticalGroup(
            kelolaStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kelolaStockLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCariStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bCariStock)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SimpanEditStock)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabUtama.addTab("tab6", kelolaStock);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setText("Riwayat Transaksi");

        bCariTransaksi.setText("Cari");

        tableTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(tableTransaksi);

        javax.swing.GroupLayout panelRiwayatLayout = new javax.swing.GroupLayout(panelRiwayat);
        panelRiwayat.setLayout(panelRiwayatLayout);
        panelRiwayatLayout.setHorizontalGroup(
            panelRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRiwayatLayout.createSequentialGroup()
                .addContainerGap(49, Short.MAX_VALUE)
                .addGroup(panelRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRiwayatLayout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addGap(320, 320, 320))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRiwayatLayout.createSequentialGroup()
                        .addGroup(panelRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(bCariTransaksi)
                            .addComponent(txtTransaksi)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 665, Short.MAX_VALUE))
                        .addGap(40, 40, 40))))
        );
        panelRiwayatLayout.setVerticalGroup(
            panelRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRiwayatLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bCariTransaksi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        tabUtama.addTab("tab7", panelRiwayat);

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabUtama, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabUtama)
        );

        navMainMenu.setText("Main Menu");
        navMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navMainMenuActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Kelola Bahan Baku");

        navTambahBahan.setText("Tambah Bahan Baku");
        navTambahBahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navTambahBahanActionPerformed(evt);
            }
        });

        navLihatBahan.setText("Lihat Bahan Baku");
        navLihatBahan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navLihatBahanActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Rexx\\Documents\\NetBeansProjects\\Laila\\AppTokoRoti\\src\\main\\resources\\assets\\Untitled-2.png")); // NOI18N

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Kelola Produk");

        navTambahProduk.setText("Tambah Produk");
        navTambahProduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navTambahProdukActionPerformed(evt);
            }
        });

        navKelolaStock.setText("Kelola Produk");
        navKelolaStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navKelolaStockActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("Kelola Transaksi");

        navRiwayat.setText("Riwayat Transaksi");
        navRiwayat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navRiwayatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(64, 64, 64))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(navMainMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(navTambahBahan, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                            .addComponent(navLihatBahan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(navTambahProduk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(navKelolaStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(navRiwayat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(navMainMenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(navTambahBahan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(navLihatBahan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(navTambahProduk)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(navKelolaStock)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(navRiwayat)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void navMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navMainMenuActionPerformed
        tabUtama.setSelectedComponent(mainMenu);
    }//GEN-LAST:event_navMainMenuActionPerformed

    private void navTambahBahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navTambahBahanActionPerformed
        tabUtama.setSelectedComponent(panelTambah);
    }//GEN-LAST:event_navTambahBahanActionPerformed

    private void navLihatBahanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navLihatBahanActionPerformed
        tabUtama.setSelectedComponent(panelLihat);
    }//GEN-LAST:event_navLihatBahanActionPerformed

//GEN-FIRST:event_textLihatProdukInputMethodTextChanged
 
//GEN-LAST:event_textLihatProdukInputMethodTextChanged

    // button cari di menu lihat produk
    private void cariBahanBakuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariBahanBakuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cariBahanBakuActionPerformed

//GEN-FIRST:event_bSimpanEditProdukActionPerformed
 
//GEN-LAST:event_bSimpanEditProdukActionPerformed

//GEN-FIRST:event_editHargaProdukInputMethodTextChanged
 
//GEN-LAST:event_editHargaProdukInputMethodTextChanged

//GEN-FIRST:event_cariEditKodeProdukInputMethodTextChanged
 
//GEN-LAST:event_cariEditKodeProdukInputMethodTextChanged

//GEN-FIRST:event_tambahHargaProdukInputMethodTextChanged
 
//GEN-LAST:event_tambahHargaProdukInputMethodTextChanged

//GEN-FIRST:event_tambahJenisProdukInputMethodTextChanged
 
//GEN-LAST:event_tambahJenisProdukInputMethodTextChanged

//GEN-FIRST:event_tambahNamaProdukInputMethodTextChanged
 
//GEN-LAST:event_tambahNamaProdukInputMethodTextChanged

//GEN-FIRST:event_tambahKodeProdukInputMethodTextChanged
 
//GEN-LAST:event_tambahKodeProdukInputMethodTextChanged

    private void tambahBahanBakuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahBahanBakuActionPerformed
        try {
            // Ambil input untuk masing-masing bahan
            String idTelur = "B001";
            String idTerigu = "B002";
            String idGaram = "B003";
            String idGula = "B004";
            String idSusu = "B005";

            // Tambahkan bahan Telur
            Double telur = Double.parseDouble(txtTelur.getText().trim());
            if (telur > 0) {
                BahanBaku bTelur = new BahanBaku(idTelur, "Telur", telur);
                BahanBakuService.addBahan(bTelur);
            }

            // Tambahkan bahan Terigu
            Double terigu = Double.parseDouble(txtTerigu.getText().trim());
            if (terigu > 0) {
                BahanBaku bTerigu = new BahanBaku(idTerigu, "Terigu", terigu);
                BahanBakuService.addBahan(bTerigu);
            }

            // Tambahkan bahan Garam
            Double garam = Double.parseDouble(txtGaram.getText().trim());
            if (garam > 0) {
                BahanBaku bGaram = new BahanBaku(idGaram, "Garam", garam);
                BahanBakuService.addBahan(bGaram);
            }

            // Tambahkan bahan Gula
            Double gula = Double.parseDouble(txtGula.getText().trim());
            if (gula > 0) {
                BahanBaku bGula = new BahanBaku(idGula, "Gula", gula);
                BahanBakuService.addBahan(bGula);
            }

            // Tambahkan bahan Susu
            Double susu = Double.parseDouble(txtSusu.getText().trim());
            if (susu > 0) {
                BahanBaku bSusu = new BahanBaku(idSusu, "Susu", susu);
                BahanBakuService.addBahan(bSusu);
            }

            refreshTableBahan(); // update JTable

            // Bersihkan form
            txtTelur.setText("");
            txtTerigu.setText("");
            txtGaram.setText("");
            txtGula.setText("");
            txtSusu.setText("");

            JOptionPane.showMessageDialog(this, "Bahan baku berhasil ditambahkan");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Semua input harus berupa angka");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage());
        }
    }//GEN-LAST:event_tambahBahanBakuActionPerformed

    private void txtBahanBakuInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtBahanBakuInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBahanBakuInputMethodTextChanged

    private void txtTelurInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtTelurInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelurInputMethodTextChanged

    private void txtTeriguInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtTeriguInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTeriguInputMethodTextChanged

    private void txtGaramInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtGaramInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGaramInputMethodTextChanged

    private void txtGulaInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtGulaInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGulaInputMethodTextChanged

    private void txtSusuInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtSusuInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSusuInputMethodTextChanged

    private void txtCariStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCariStockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCariStockActionPerformed

    private void bCariStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCariStockActionPerformed
        String keyword = txtCariStock.getText().toLowerCase();
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tableStock.getModel();
        model.setRowCount(0);

        for (Produk p : listProduk) {
            if (p.getNama().toLowerCase().contains(keyword) || p.getKode().toLowerCase().contains(keyword)) {
                model.addRow(new Object[] {
                    p.getKode(),
                    p.getNama(),
                    p.getKategori().getDeskripsi(),
                    p.getStokProduk(),
                    p.getDeskripsi(),
                    p.getHarga()
                });
            }
        }
    }//GEN-LAST:event_bCariStockActionPerformed

    private void navKelolaStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navKelolaStockActionPerformed
        tabUtama.setSelectedComponent(kelolaStock);
        refreshTableStock();
    }//GEN-LAST:event_navKelolaStockActionPerformed

    private void SimpanEditStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SimpanEditStockActionPerformed
        int selectedRow = tableStock.getSelectedRow();
        if (selectedRow >= 0) {
            String kode = tableStock.getValueAt(selectedRow, 0).toString();
            Produk produk = ProdukService.getListProduk().stream()
                .filter(p -> p.getKode().equals(kode))
                .findFirst().orElse(null);
            if (produk != null) {
                try {
                    int newStok = Integer.parseInt(tableStock.getValueAt(selectedRow, 3).toString());
                    produk.setStokProduk(newStok);
                    refreshTableStock();
                    JOptionPane.showMessageDialog(this, "Stok berhasil diperbarui");
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Jumlah stok harus angka");
                }
            }
        }
    }//GEN-LAST:event_SimpanEditStockActionPerformed

    private void navTambahProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navTambahProdukActionPerformed
        tabUtama.setSelectedComponent(tambahProduk);
    }//GEN-LAST:event_navTambahProdukActionPerformed

    private void bTambahProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTambahProdukActionPerformed
        try {
            String kode = txtKode.getText().trim();
            String nama = txtNama.getText().trim();
            Double harga = Double.parseDouble(txtHarga.getText().trim());
            String kategoriStr = (String) comboKategori.getSelectedItem(); // ambil String dari combo box
            KategoriRoti kategori;

            // konversi String ke enum
            switch (kategoriStr) {
                case "Tawar": kategori = KategoriRoti.TAWAR; break;
                case "Manis": kategori = KategoriRoti.MANIS; break;
                case "Asin": kategori = KategoriRoti.ASIN; break;
                default: kategori = KategoriRoti.TAWAR; break;
            }

            Integer stokProduk = Integer.parseInt(txtStok.getText().trim());
            String deskripsi = txtDeskripsi.getText().trim();

            // buat objek produk
            Produk produkBaru = new Produk(kode, nama, harga, kategori, stokProduk, deskripsi);

            // tambahkan ke service
            ProdukService.tambahProduk(produkBaru);

            // refresh JTable
            refreshTableStock();

            // bersihkan form
            txtKode.setText("");
            txtNama.setText("");
            txtHarga.setText("");
            comboKategori.setSelectedIndex(0);
            txtStok.setText("");
            txtDeskripsi.setText("");

            JOptionPane.showMessageDialog(this, "Produk berhasil ditambahkan");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Harga dan Stok harus angka");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage());
        }
    }//GEN-LAST:event_bTambahProdukActionPerformed

    private void navRiwayatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navRiwayatActionPerformed
        tabUtama.setSelectedComponent(panelRiwayat);
        refreshTableTransaksi();
        loadRiwayatTransaksi();
    }//GEN-LAST:event_navRiwayatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new UI_Manager().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SimpanEditStock;
    private javax.swing.JButton bCariStock;
    private javax.swing.JButton bCariTransaksi;
    private javax.swing.JButton bTambahProduk;
    private javax.swing.JPanel bg;
    private javax.swing.JButton cariBahanBaku;
    private javax.swing.JComboBox<String> comboKategori;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JPanel kelolaStock;
    private javax.swing.JPanel mainMenu;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JButton navKelolaStock;
    private javax.swing.JButton navLihatBahan;
    private javax.swing.JButton navMainMenu;
    private javax.swing.JButton navRiwayat;
    private javax.swing.JButton navTambahBahan;
    private javax.swing.JButton navTambahProduk;
    private javax.swing.JPanel panelLihat;
    private javax.swing.JPanel panelRiwayat;
    private javax.swing.JPanel panelTambah;
    private javax.swing.JTabbedPane tabUtama;
    private javax.swing.JTable tabelBahanBaku;
    private javax.swing.JTable tableStock;
    private javax.swing.JTable tableTransaksi;
    private javax.swing.JButton tambahBahanBaku;
    private javax.swing.JPanel tambahProduk;
    private javax.swing.JTextField txtBahanBaku;
    private javax.swing.JTextField txtCariStock;
    private javax.swing.JTextField txtDeskripsi;
    private javax.swing.JTextField txtGaram;
    private javax.swing.JTextField txtGula;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtKode;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtStok;
    private javax.swing.JTextField txtSusu;
    private javax.swing.JTextField txtTelur;
    private javax.swing.JTextField txtTerigu;
    private javax.swing.JTextField txtTransaksi;
    // End of variables declaration//GEN-END:variables
}
