package com.mycompany.apptokoroti;

import com.mycompany.apptokoroti.Kasir;
import java.util.ArrayList;
import java.util.List;

public class KasirService {
    private List<Produk> daftarProduk;

    public List<Kasir> getAllKasir() {
        List<Kasir> list = new ArrayList<>();

        list.add(new Kasir("KSR001", "Andi"));
        list.add(new Kasir("KSR002", "Budi"));
        list.add(new Kasir("KSR003", "Siti"));

        return list;
    }
}
