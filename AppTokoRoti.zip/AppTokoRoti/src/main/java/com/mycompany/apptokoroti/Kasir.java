package com.mycompany.apptokoroti;

public class Kasir {
    private String id;
    private String nama;

    public Kasir(String id, String nama) {
        this.id = id;
        this.nama = nama;
    }

    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    @Override
    public String toString() {
        return nama;
    }
}
