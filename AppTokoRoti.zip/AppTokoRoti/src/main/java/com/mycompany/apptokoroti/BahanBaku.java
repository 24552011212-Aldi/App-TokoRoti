package com.mycompany.apptokoroti;

public class BahanBaku extends Item {
    private String id;        // ID bahan
    private String nama;      // Nama bahan (Telur, Terigu, Garam, Gula, Susu)
    private Double quantity;  // Jumlah bahan (kg)

    // Constructor berparameter
    public BahanBaku(String id, String nama, Double quantity) {
        super("", "", 0.0);  // Harga tidak relevan untuk bahan baku
        this.id = id;
        this.nama = nama;
        this.quantity = quantity;
    }

    // Default constructor
    public BahanBaku() {
        super("", "", 0.0);
        this.id = "";
        this.nama = "";
        this.quantity = 0.0;
    }

    // Getter & Setter
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }

    // Method untuk menambah dan mengurangi stok
    public void tambahQuantity(Double jumlah) { this.quantity += jumlah; }
    public boolean kurangiQuantity(Double jumlah) {
        if (quantity >= jumlah) { quantity -= jumlah; return true; }
        return false;
    }

    @Override
    public String getTipeItem() {
        return "Bahan Baku";
    }

    // Implementasi Storable
    @Override
    public String toFileString() {
        return id + "|" + nama + "|" + quantity;
    }

    @Override
    public void fromFileString(String data) {
        String[] parts = data.split("\\|");
        if (parts.length >= 3) {
            id = parts[0];
            nama = parts[1];
            quantity = Double.parseDouble(parts[2]);
        }
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nama: " + nama + ", Quantity: " + quantity + " kg";
    }
}
