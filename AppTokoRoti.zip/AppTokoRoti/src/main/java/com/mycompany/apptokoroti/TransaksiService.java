package com.mycompany.apptokoroti;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * TransaksiService - Implementasi IOperasiData
 * Logika pemrosesan transaksi dan penghitungan kembalian dengan JSON file handling
 */
public class TransaksiService implements IOperasiData<String> {
    
    // Atribut private
    private static final double RotiTawar = 15000;
    private static final double RotiAsin = 16000;
    private static final double RotiManis = 18000;
    private List<Produk> daftarProduk;


    private String namaKasir; // Nama kasir default (tidak digunakan jika diinput per transaksi)
    private double totalTransaksi; // Total nilai semua transaksi yang tercatat
    private final List<String> riwayatTransaksi; // Riwayat semua transaksi
    
    // Constructor berparameter
    public TransaksiService() {
        this.namaKasir = namaKasir;
        this.totalTransaksi = 0.0;
        this.riwayatTransaksi = new ArrayList<>();
    }
    
    public double hitungTotalRoti(Produk produk, int jumlah) {
        return produk.hitungHargaKategori() * jumlah;
    }




    
    // Getter dan Setter
    public String getNamaKasir() {
        return namaKasir;
    }
    
    public void setNamaKasir(String namaKasir) {
        this.namaKasir = namaKasir;
    }
    
    public double getTotalTransaksi() {
        return totalTransaksi;
    }
    
    public void setTotalTransaksi(double totalTransaksi) {
        this.totalTransaksi = totalTransaksi;
    }
    
    public List<String> getRiwayatTransaksi() {
        return riwayatTransaksi;
    }
    
    // Method 1: Implementasi interface - Load data dari JSON file
    @Override
    public void loadDataFromFile() {
        String filePath = "data/transaksi_log.json";
        riwayatTransaksi.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean mulaiArray = false;

            while ((line = br.readLine()) != null) {
                line = line.trim();

                if (line.startsWith("\"riwayatTransaksi\"")) {
                    mulaiArray = true;
                    continue;
                }

                if (mulaiArray) {
                    if (line.startsWith("]")) break;

                    line = line.replace("\"", "").replace(",", "").trim();
                    if (!line.isEmpty()) {
                        riwayatTransaksi.add(line);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    
    // Method 2: Implementasi interface - Save data ke JSON file
    @Override
    public void saveDataToFile() {
        String filePath = "data/transaksi_log.json";
        try {
            File dir = new File("data");
            if (!dir.exists()) dir.mkdirs();

            StringBuilder json = new StringBuilder();
            json.append("{\n");
            json.append("\"namaKasir\":\"").append(namaKasir).append("\",\n");
            json.append("\"totalTransaksi\":").append(totalTransaksi).append(",\n");
            json.append("\"riwayatTransaksi\":[\n");

            for (int i = 0; i < riwayatTransaksi.size(); i++) {
                json.append("\"").append(escapeJson(riwayatTransaksi.get(i))).append("\"");
                if (i < riwayatTransaksi.size() - 1) json.append(",");
                json.append("\n");
            }

            json.append("]\n}");
            try (FileWriter fw = new FileWriter(filePath)) {
                fw.write(json.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // Helper method untuk escape JSON string
    private String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }
    
    // Method 3: Proses transaksi penjualan
    /**
     * Memproses transaksi penjualan dengan validasi pembayaran
     * @param namaKasir Nama kasir yang melayani transaksi ini
     * @param namaBarang Nama barang yang dibeli
     * @param hargaSatuan Harga satuan barang (Rp)
     * @param jumlahBarang Jumlah barang yang dibeli
     * @param uangBayar Uang yang diberikan pembeli (Rp)
     * @return Array berisi [totalHarga, uangKembali] atau [-1, -1] jika pembayaran kurang
     */
    public double[] prosesPenjualan(String namaKasir, Produk produk, int jumlahBarang, double uangBayar) {
        double totalHarga = produk.hitungHargaKategori() * jumlahBarang;
        double uangKembali = uangBayar - totalHarga;

        if (uangBayar < totalHarga) {
            return new double[] {totalHarga, -1};
        }

        totalTransaksi += totalHarga;

        String waktu = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String catatan = String.format("[%s] Kasir: %s | Barang: %s | Qty: %d | Harga/satuan: Rp%.2f | Total: Rp%.2f | Bayar: Rp%.2f | Kembalian: Rp%.2f",
                                        waktu, namaKasir, produk.getNama(), jumlahBarang, produk.hitungHargaKategori(),
                                        totalHarga, uangBayar, uangKembali);
        riwayatTransaksi.add(catatan);


        // Kurangi stok produk
        produk.kurangiStokProduk(jumlahBarang);
        saveDataToFile();

        return new double[] {totalHarga, uangKembali};
    }

    
    // Method 4: Hitung kembalian
    /**
     * Menghitung jumlah uang kembalian
     * @param totalBelanja Total harga barang belanja (Rp)
     * @param uangBayar Uang yang diberikan (Rp)
     * @return Jumlah uang kembalian (negatif jika pembayaran kurang)
     */
    public double hitungKembalian(double totalBelanja, double uangBayar) {
        double kembalian = uangBayar - totalBelanja;
        String catatan = String.format("Perhitungan Kembalian: Rp%.2f (bayar) - Rp%.2f (belanja) = Rp%.2f", 
                                      uangBayar, totalBelanja, kembalian);
        riwayatTransaksi.add(catatan);
        return kembalian;
        
    }
    
    // Method 5: Validasi pembayaran
    /**
     * Validasi apakah pembayaran cukup
     * @param totalBelanja Total harga barang (Rp)
     * @param uangBayar Uang pembayaran (Rp)
     * @return true jika pembayaran cukup, false jika kurang
     */
    public boolean validasiPembayaran(double totalBelanja, double uangBayar) {
        boolean valid = uangBayar >= totalBelanja;
        String status = valid ? "Valid - Pembayaran Cukup" : "Tidak Valid - Pembayaran Kurang";
        String catatan = String.format("Validasi Pembayaran: %s (Total: Rp%.2f | Bayar: Rp%.2f)", 
                                      status, totalBelanja, uangBayar);
        riwayatTransaksi.add(catatan);
        System.out.println("[Validasi Pembayaran] " + status);
        return valid;
    }
    
    // Method 6: Tampilkan riwayat transaksi
    /**
     * Menampilkan semua riwayat transaksi
     * (Nama kasir tercatat di setiap transaksi)
     */
    public void tampilkanRiwayatTransaksi() {
        System.out.println("\n=== RIWAYAT SEMUA TRANSAKSI ===");
        if (riwayatTransaksi.isEmpty()) {
            System.out.println("Belum ada transaksi");
            return;
        }
        for (int i = 0; i < riwayatTransaksi.size(); i++) {
            System.out.println((i + 1) + ". " + riwayatTransaksi.get(i));
        }
        System.out.println("\nTotal Transaksi: Rp " + String.format("%.2f", totalTransaksi));
    }

    
    // Implementasi CRUD methods dari interface IOperasiData
    @Override
    public void tambah(String data) {
        riwayatTransaksi.add(data);
        System.out.println("[TransaksiService] Transaksi berhasil ditambahkan");
    }
    
    @Override
    public void ubah(String data) {
        int index = riwayatTransaksi.indexOf(data);
        if (index != -1) {
            riwayatTransaksi.set(index, data);
            System.out.println("[TransaksiService] Transaksi berhasil diubah");
        }
    }
    
    @Override
    public void hapus(String id) {
        riwayatTransaksi.removeIf(transaksi -> transaksi.contains(id));
        System.out.println("[TransaksiService] Transaksi berhasil dihapus");
    }
    
    @Override
    public String cari(String id) {
        return riwayatTransaksi.stream()
                .filter(transaksi -> transaksi.contains(id))
                .findFirst()
                .orElse(null);
    }
    
    @Override
    public List<String> tampilSemua() {
        return new ArrayList<>(riwayatTransaksi);
    }
}
