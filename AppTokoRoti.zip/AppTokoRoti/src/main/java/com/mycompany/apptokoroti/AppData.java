package com.mycompany.apptokoroti;

public class AppData {
    public static final TransaksiService transaksiService = new TransaksiService();
}
