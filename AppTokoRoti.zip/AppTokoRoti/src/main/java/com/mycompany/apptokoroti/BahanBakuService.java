package com.mycompany.apptokoroti;

import java.util.ArrayList;
import java.util.List;

public class BahanBakuService {
    private static final List<BahanBaku> daftarBahan = new ArrayList<>();

    public static void addBahan(BahanBaku b) {
        daftarBahan.add(b);
    }

    public static List<BahanBaku> getListBahan() {
        return daftarBahan;
    }
}
