package com.mycompany.apptokoroti;

import java.io.*;
import java.util.List;
import com.mycompany.apptokoroti.BahanBaku;
import com.mycompany.apptokoroti.KategoriRoti;
import com.mycompany.apptokoroti.Produk;

public class FilePersistence {

    private static final String PRODUK_FILE = "data/produk_data.json";
    private static final String BAHAN_FILE = "data/bahan_baku_data.json";

    public FilePersistence() {
        File dir = new File("data");
        if (!dir.exists()) dir.mkdirs();
    }

    // =================== PRODUK ===================
    public void loadProdukFromFile(List<Produk> daftarProduk) {
        File file = new File(PRODUK_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.startsWith("{")) continue;
                if (line.endsWith(",")) line = line.substring(0, line.length() - 1);
                parseProdukLine(line, daftarProduk);
            }
        } catch (IOException e) {
            System.out.println("[FilePersistence ERROR] Gagal membaca file produk: " + e.getMessage());
        }
    }

    public void saveProdukToFile(List<Produk> daftarProduk) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUK_FILE))) {
            writer.write("[\n");
            for (int i = 0; i < daftarProduk.size(); i++) {
                Produk p = daftarProduk.get(i);
                writer.write("  {\"kode\":\"" + p.getKode() + "\",");
                writer.write("\"nama\":\"" + p.getNama() + "\",");
                writer.write("\"harga\":" + p.getHarga() + ",");
                writer.write("\"kategori\":\"" + p.getKategori().name() + "\",");
                writer.write("\"stok\":" + p.getStokProduk() + ",");
                writer.write("\"deskripsi\":\"" + escapeJson(p.getDeskripsi()) + "\"}");
                if (i < daftarProduk.size() - 1) writer.write(",");
                writer.write("\n");
            }
            writer.write("]");
        } catch (IOException e) {
            System.out.println("[FilePersistence ERROR] Gagal menulis file produk: " + e.getMessage());
        }
    }

    // =================== BAHAN BAKU ===================
    public void loadBahanBakuFromFile(List<BahanBaku> daftarBahanBaku) {
        File file = new File(BAHAN_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.startsWith("{")) continue;
                if (line.endsWith(",")) line = line.substring(0, line.length() - 1);
                parseBahanBakuLine(line, daftarBahanBaku);
            }
        } catch (IOException e) {
            System.out.println("[FilePersistence ERROR] Gagal membaca file bahan baku: " + e.getMessage());
        }
    }

    public void saveBahanBakuToFile(List<BahanBaku> daftarBahanBaku) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BAHAN_FILE))) {
            writer.write("[\n");
            for (int i = 0; i < daftarBahanBaku.size(); i++) {
                BahanBaku b = daftarBahanBaku.get(i);
                writer.write("  {\"id\":\"" + b.getId() + "\",");
                writer.write("\"nama\":\"" + b.getNama() + "\",");
                writer.write("\"quantity\":" + b.getQuantity() + "}");
                if (i < daftarBahanBaku.size() - 1) writer.write(",");
                writer.write("\n");
            }
            writer.write("]");
        } catch (IOException e) {
            System.out.println("[FilePersistence ERROR] Gagal menulis file bahan baku: " + e.getMessage());
        }
    }


    // =================== PARSING ===================
    private void parseProdukLine(String line, List<Produk> daftarProduk) {
        try {
            String kode = extractJsonValue(line, "kode");
            String nama = extractJsonValue(line, "nama");
            Double harga = Double.parseDouble(extractJsonValue(line, "harga"));
            String kategoriStr = extractJsonValue(line, "kategori");
            Integer stok = Integer.parseInt(extractJsonValue(line, "stok"));
            String deskripsi = extractJsonValue(line, "deskripsi");

            KategoriRoti kategori = KategoriRoti.valueOf(kategoriStr);
            Produk produk = new Produk(kode, nama, harga, kategori, stok, deskripsi);
            daftarProduk.add(produk);
        } catch (Exception e) {
            System.out.println("[FilePersistence ERROR] Gagal parse Produk: " + e.getMessage());
        }
    }

    private void parseBahanBakuLine(String line, List<BahanBaku> daftarBahanBaku) {
        try {
            String id = extractJsonValue(line, "id");
            String nama = extractJsonValue(line, "nama");
            Double quantity = Double.parseDouble(extractJsonValue(line, "quantity"));

            BahanBaku b = new BahanBaku(id, nama, quantity);
            daftarBahanBaku.add(b);
        } catch (Exception e) {
            System.out.println("[FilePersistence ERROR] Gagal parse BahanBaku: " + e.getMessage());
        }
    }


    // =================== HELPER ===================
    private String extractJsonValue(String line, String key) {
        String pattern = "\"" + key + "\":";
        int startIdx = line.indexOf(pattern);
        if (startIdx == -1) return "";
        startIdx += pattern.length();
        while (startIdx < line.length() && Character.isWhitespace(line.charAt(startIdx))) startIdx++;
        if (line.charAt(startIdx) == '"') {
            startIdx++;
            int endIdx = line.indexOf("\"", startIdx);
            return line.substring(startIdx, endIdx);
        } else {
            int endIdx = startIdx;
            while (endIdx < line.length() && line.charAt(endIdx) != ',' && line.charAt(endIdx) != '}') endIdx++;
            return line.substring(startIdx, endIdx).trim();
        }
    }

    private String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }
}
