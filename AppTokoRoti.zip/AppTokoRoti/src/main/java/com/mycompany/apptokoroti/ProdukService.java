package com.mycompany.apptokoroti;

import java.util.ArrayList;
import java.util.List;

public class ProdukService {

    private static final List<Produk> listProduk = new ArrayList<>();

    public static List<Produk> getListProduk() {
        return listProduk;
    }

    public static void tambahProduk(Produk p) {
        listProduk.add(p);
    }

    public static void hapusProduk(int index) {
        if (index >= 0 && index < listProduk.size()) {
            listProduk.remove(index);
        }
    }

    public static void updateProduk(int index, Produk p) {
        if (index >= 0 && index < listProduk.size()) {
            listProduk.set(index, p);
        }
    }
}
