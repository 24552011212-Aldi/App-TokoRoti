package com.mycompany.apptokoroti;

/**
 * Enum untuk kategori roti
 * Memenuhi requirement: Enum Type
 */
public enum KategoriRoti {
    TAWAR("Tawar"),
    MANIS("Manis"),
    ASIN("Asin");

    private final String deskripsi;

    KategoriRoti(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getDeskripsi() {
        return deskripsi;
    }
}
